QBCore startup fix applied

What I changed:
- init.lua now defaults inventory:framework to "qb" instead of "esx".
- This prevents ox_inventory from loading the ESX bridge when config.cfg has not been executed before the resource starts.

Still recommended in server.cfg:
1. Put this before ensure ox_inventory:
   exec @ox_inventory/config.cfg

2. Start resources in this order:
   ensure oxmysql
   ensure ox_lib
   ensure qb-core
   ensure ox_inventory

3. Do not ensure es_extended or esx_license on a QBCore server.

The original errors came from ox_inventory loading the ESX bridge, which caused it to look for:
- exports.es_extended:getSharedObject()
- table licenses
- table owned_vehicles

For QBCore, ox_inventory should use the qb bridge and player_vehicles, not owned_vehicles.
